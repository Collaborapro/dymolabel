from odoo import models, fields, api, _

class PickingProductLabelWizard(models.TransientModel):
    _name = "picking.product.label.wizard"

    def _get_product_domain(self):
        active_id = self.env.context.get('active_id')
        if self.env.context.get('active_model') == 'stock.picking' and active_id:
            picking = self.env['stock.picking'].browse(active_id)
            product_ids = []
            for move in picking.move_ids_without_package:
                product_ids.append(move.product_id.id)
            return [('id', 'in', product_ids)]

    product_id = fields.Many2one('product.product', 'Product', domain=_get_product_domain,)

    def action_print_report_product_label(self):
        active_id = self.env.context.get('active_id')
        if self.env.context.get('active_model') == 'stock.picking' and active_id:
            picking = self.env['stock.picking'].browse(active_id)
            vals_list = []
            for move in picking.move_ids_without_package:
                if self.product_id.id == move.product_id.id:
                    vals = {
                        'date_done': picking.date_done,
                        'po': picking.origin,
                        'name': picking.name,
                        'product_id': move.product_id.name,
                        'quantity_done': move.quantity_done,
                    }

                    vals_list.append(vals)
            data = {
                'form_data': self.read()[0],
                'vals_list': vals_list,
            }
            return self.env.ref('iwesabe_print_product_label_picking.action_report_product_label_picking_qweb').report_action(self, data=data)

